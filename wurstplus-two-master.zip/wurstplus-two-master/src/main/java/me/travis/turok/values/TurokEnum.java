package me.travis.turok.values;

/**
* @author me
*
* Created by me.
* 08/04/20.
*
*/
public class TurokEnum {
	Class<? extends java.lang.Enum> value;

	public TurokEnum(Class<? extends java.lang.Enum> _enum) {
		this.value = _enum;
	}
}